package com.example.cw8

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
