package com.example.hw8_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
